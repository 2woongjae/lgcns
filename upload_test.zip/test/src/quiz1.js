import React, { useCallback } from "react";
import { useDispatch, useSelector } from "react-redux";
import { goBack } from "connected-react-router";

import Add from "../components/Add";
import { logout as logoutSaga } from "../redux/modules/auth";
import {
  addBook as addBookSaga,
  getBooks as getBooksSaga,
} from "../redux/modules/books";

const AddContainer = () => {
  const books = useSelector((state) => state.books.books);
  const loading = useSelector((state) => state.books.loading);
  const error = useSelector((state) => state.books.error);
  const dispatch = useDispatch();

  const getBooks = useCallback(() => {
    dispatch(getBooksSaga());
  }, [dispatch]);

  const add = useCallback(
    (book) => {
      dispatch(addBookSaga(book));
    },
    [dispatch]
  );

  const back = useCallback(() => {
    dispatch(goBack());
  }, [dispatch]);

  const logout = useCallback(() => {
    dispatch(logoutSaga());
  }, [dispatch]);

  return (
    <Add
      books={books}
      loading={loading}
      error={error}
      add={add}
      getBooks={getBooks}
      back={back}
      logout={logout}
    />
  );
};

export default AddContainer;
